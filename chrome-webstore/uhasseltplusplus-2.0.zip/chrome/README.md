# UHasselt Plus Plus
UHasselt Plus Plus is a plugin that aims to update mijnstudentendosier.uhasselt.be to look more modern and have modern functionality.

# Development guide
>**_NOTE_** It is currently not possible for unpermitted users to contribute to this project

## setup the local repo
To start contributing create a new branch from dev named: feature-"featurename"
Clone the repo via git clone and checkout your new branch.
Make your changes and push changes to github.
Create a pull request and aprove it or wait for it to be approved if you can't approve it yourself.

### tailwind setup
Tailwind uses the compiled.css file to store its styles. To make sure it gets updated correctly run `npm run build:css` and keep the terminal open while working on the project. When changing things to do with Tailwind make sure to reload the extension.

### Adding content to a page
In the code bellow the route is matched and the appropriate function is called (in default.js)
Not all functions are yet implemented.
```javascript
switch (route) {
        case "/Default.aspx":
          loadHomeContent(tables);
          break;
        // other cases...
        case "/sdsActiviteitenStudNieuw.aspx?activiteit=STARTUP":
          loadStartUpContent(tables);
          break;
        default:
          loadHomeContent(tables);
          break;
```

To implement a new content page function:
- 1. create a branch feature-< content name > from source: dev
- 2. add the function definition under the other, earlier content loader definitions
- 3. use the template bellow (replace 'Home' with the actual content name)
- 4. in `src/pages/content` create a html file and pass its name as value to 'page:' as seen bellow
- 5. use javascript magic to extract data from 'tables' and insert it into the injected html

```javascript
function loadHomeContent(tables) {
    chrome.runtime.sendMessage(
        { action: "GET::html", page: "home", lang:  settings_global.lang},
        (response) => {
            if (response.html) {
            placeholder.innerHTML = response.html;

                // handle the editing of the response.html with content out of 'tables'
            }
        }
    );
}

```
## Managing settings
This extension uses a background process to manage saving to the settings.
To save settings you have to send a message with the action "POST:settings"
The message wil change a single setting.

example: (change "key" and "value" to the appropriate setting and value)
```javascript
chrome.runtime.sendMessage({
        action: "POST::settings",
        key: "key",
        value: "value"
})
```
> **_NOTE_** There is also an action "POST::settingsFull" but it overwrites ALL settings so try to not use it. (this takes in the settings json in the data field instead of key and value)

to get the settings you need to send a message with the action "GET::settings".
The response will be the entire settings json.
```javascript
chrome.runtime.sendMessage({ action: "GET::settings" }, (response)=>{
        const settings = respons.settings
        // use the settings json
})
```

## Running the plugin for testing
Go to [Chrome extensions](chrome://extensions/)
Enable developer mode.
Click on "Load unpacked" and select the chrome chrome folder inside this repo.
Chrome should now have loaded the extension and you should be all set to start commiting.

# Supported browsers
* [x] Chrome
* [ ] Firefox



